﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace zd2_VankovPavel
{
    public partial class AddContactForm : Form
    {
        public string ContactName => txtName.Text;
        public string PhoneNumber => txtPhone.Text;

        public AddContactForm()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            // Проверка имени
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите имя контакта!", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Проверка что имя содержит только буквы и пробелы
            foreach (char c in txtName.Text)
            {
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    MessageBox.Show("Имя может содержать только буквы и пробелы!", "Ошибка",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // Проверка телефона
            if (string.IsNullOrWhiteSpace(txtPhone.Text))
            {
                MessageBox.Show("Введите номер телефона!", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Упрощенная проверка телефона (только цифры)
            string cleanPhone = new string(txtPhone.Text.Where(ch => char.IsDigit(ch)).ToArray());
            if (cleanPhone.Length < 7)
            {
                MessageBox.Show("Номер телефона слишком короткий! Должно быть минимум 7 цифр.", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}