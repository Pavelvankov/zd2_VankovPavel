﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace zd2_VankovPavel
{
    public partial class AddContactOverloadForm : Form
    {
        public string ContactData => txtContact.Text;

        public AddContactOverloadForm()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            // Проверка что что-то введено
            if (string.IsNullOrWhiteSpace(txtContact.Text))
            {
                MessageBox.Show("Введите данные контакта!", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Разделение на имя и телефон
            string[] parts = txtContact.Text.Split(';');
            if (parts.Length != 2)
            {
                MessageBox.Show("Введите данные в формате: Имя;Телефон", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string name = parts[0].Trim();
            string phone = parts[1].Trim();

            // Проверка имени
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Введите имя контакта!", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Проверка что имя содержит только буквы и пробелы
            foreach (char c in name)
            {
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    MessageBox.Show("Имя может содержать только буквы и пробелы!", "Ошибка",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // Упрощенная проверка телефона (только цифры)
            string cleanPhone = new string(phone.Where(ch => char.IsDigit(ch)).ToArray());
            if (cleanPhone.Length < 7)
            {
                MessageBox.Show("Номер телефона слишком короткий! Должно быть минимум 7 цифр.", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}