﻿using System;

namespace zd2_VankovPavel
{
    public class Contact
    {
        public string Name { get; set; }  // Имя контакта
        public string Phone { get; set; }  // Номер телефона

        public override string ToString()
        {
            return $"{Name}: {Phone}";
        }
    }
}