﻿using System;
using System.Windows.Forms;

namespace zd2_VankovPavel
{
    public partial class DeleteContactForm : Form
    {
        public string ContactName => txtName.Text;

        public DeleteContactForm()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите имя контакта", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}