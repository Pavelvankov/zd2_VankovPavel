﻿namespace zd2_VankovPavel
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранениеВФайлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.контактыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выводВсехКонтактовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалениеКонтактаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавлениеКонтактаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.перегрузкаМетодаДобавленияКонтактToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.перегрузкаМетодаУдаленияКонтактаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 58);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(321, 446);
            this.listBox1.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.контактыToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(345, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сохранениеВФайлToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // сохранениеВФайлToolStripMenuItem
            // 
            this.сохранениеВФайлToolStripMenuItem.Name = "сохранениеВФайлToolStripMenuItem";
            this.сохранениеВФайлToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.сохранениеВФайлToolStripMenuItem.Text = "Сохранение в файл";
            this.сохранениеВФайлToolStripMenuItem.Click += new System.EventHandler(this.сохранениеВФайлToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // контактыToolStripMenuItem
            // 
            this.контактыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выводВсехКонтактовToolStripMenuItem,
            this.удалениеКонтактаToolStripMenuItem,
            this.добавлениеКонтактаToolStripMenuItem,
            this.перегрузкаМетодаДобавленияКонтактToolStripMenuItem,
            this.перегрузкаМетодаУдаленияКонтактаToolStripMenuItem});
            this.контактыToolStripMenuItem.Name = "контактыToolStripMenuItem";
            this.контактыToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.контактыToolStripMenuItem.Text = "Контакты";
            // 
            // выводВсехКонтактовToolStripMenuItem
            // 
            this.выводВсехКонтактовToolStripMenuItem.Name = "выводВсехКонтактовToolStripMenuItem";
            this.выводВсехКонтактовToolStripMenuItem.Size = new System.Drawing.Size(282, 22);
            this.выводВсехКонтактовToolStripMenuItem.Text = "Вывод всех контактов";
            // 
            // удалениеКонтактаToolStripMenuItem
            // 
            this.удалениеКонтактаToolStripMenuItem.Name = "удалениеКонтактаToolStripMenuItem";
            this.удалениеКонтактаToolStripMenuItem.Size = new System.Drawing.Size(282, 22);
            this.удалениеКонтактаToolStripMenuItem.Text = "удаление контакта";
            this.удалениеКонтактаToolStripMenuItem.Click += new System.EventHandler(this.удалениеКонтактаToolStripMenuItem_Click);
            // 
            // добавлениеКонтактаToolStripMenuItem
            // 
            this.добавлениеКонтактаToolStripMenuItem.Name = "добавлениеКонтактаToolStripMenuItem";
            this.добавлениеКонтактаToolStripMenuItem.Size = new System.Drawing.Size(282, 22);
            this.добавлениеКонтактаToolStripMenuItem.Text = "Добавление контакта";
            this.добавлениеКонтактаToolStripMenuItem.Click += new System.EventHandler(this.добавлениеКонтактаToolStripMenuItem_Click);
            // 
            // перегрузкаМетодаДобавленияКонтактToolStripMenuItem
            // 
            this.перегрузкаМетодаДобавленияКонтактToolStripMenuItem.Name = "перегрузкаМетодаДобавленияКонтактToolStripMenuItem";
            this.перегрузкаМетодаДобавленияКонтактToolStripMenuItem.Size = new System.Drawing.Size(282, 22);
            this.перегрузкаМетодаДобавленияКонтактToolStripMenuItem.Text = "добавления контакт (перегрузка)";
            this.перегрузкаМетодаДобавленияКонтактToolStripMenuItem.Click += new System.EventHandler(this.перегрузкаМетодаДобавленияКонтактToolStripMenuItem_Click);
            // 
            // перегрузкаМетодаУдаленияКонтактаToolStripMenuItem
            // 
            this.перегрузкаМетодаУдаленияКонтактаToolStripMenuItem.Name = "перегрузкаМетодаУдаленияКонтактаToolStripMenuItem";
            this.перегрузкаМетодаУдаленияКонтактаToolStripMenuItem.Size = new System.Drawing.Size(256, 22);
            this.перегрузкаМетодаУдаленияКонтактаToolStripMenuItem.Text = "Удаления контакта (перегрузка)";
            this.перегрузкаМетодаУдаленияКонтактаToolStripMenuItem.Click += new System.EventHandler(this.перегрузкаМетодаУдаленияКонтактаToolStripMenuItem_Click);
            // 
            // textBox1
            // 
            this.textBox1.AccessibleName = "";
            this.textBox1.Location = new System.Drawing.Point(12, 31);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(240, 20);
            this.textBox1.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.Snow;
            this.button1.Location = new System.Drawing.Point(258, 31);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 20);
            this.button1.TabIndex = 3;
            this.button1.Text = "Поиск";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(345, 516);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Телефонная книга";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem контактыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выводВсехКонтактовToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem сохранениеВФайлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалениеКонтактаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавлениеКонтактаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem перегрузкаМетодаДобавленияКонтактToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem перегрузкаМетодаУдаленияКонтактаToolStripMenuItem;
    }
}