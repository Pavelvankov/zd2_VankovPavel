﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace zd2_VankovPavel
{
    public partial class Form1 : Form
    {
        private PhoneBook phoneBook = new PhoneBook(); // Телефонная книга
        private string currentFile = "contacts.csv";   // Текущий файл

        public Form1()
        {
            InitializeComponent();
            LoadContacts(); // Загрузка контактов
        }

        // Загрузка контактов
        private void LoadContacts()
        {
            try
            {
                PhoneBookLoader.Load(phoneBook, currentFile);
                DisplayContacts(phoneBook.GetAllContacts());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Отображение контактов
        private void DisplayContacts(List<Contact> contacts)
        {
            listBox1.Items.Clear();
            foreach (var contact in contacts)
            {
                listBox1.Items.Add(contact);
            }
        }

        // Показать все контакты
        private void выводВсехКонтактовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DisplayContacts(phoneBook.GetAllContacts());
            textBox1.Clear();
        }

        // Добавить контакт
        private void добавлениеКонтактаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var form = new AddContactForm())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    phoneBook.AddContact(form.ContactName, form.PhoneNumber);
                    DisplayContacts(phoneBook.GetAllContacts());
                }
            }
        }

        // Добавить контакт (перегрузка)
        private void перегрузкаМетодаДобавленияКонтактToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var form = new AddContactOverloadForm())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    var parts = form.ContactData.Split(';');
                    if (parts.Length == 2)
                    {
                        var contact = new Contact { Name = parts[0].Trim(), Phone = parts[1].Trim() };
                        phoneBook.AddContact(contact);
                        DisplayContacts(phoneBook.GetAllContacts());
                    }
                }
            }
        }

        // Удалить контакт
        private void удалениеКонтактаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var form = new DeleteContactForm())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    phoneBook.RemoveContact(form.ContactName);
                    DisplayContacts(phoneBook.GetAllContacts());
                }
            }
        }

        // Удалить контакт (перегрузка)
        private void перегрузкаМетодаУдаленияКонтактаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem is Contact selectedContact)
            {
                phoneBook.RemoveContact(selectedContact);
                DisplayContacts(phoneBook.GetAllContacts());
            }
            else
            {
                MessageBox.Show("Выберите контакт для удаления", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Сохранить в файл
        private void сохранениеВФайлToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                PhoneBookLoader.Save(phoneBook, currentFile);
                MessageBox.Show("Контакты сохранены", "Успех",
                              MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Выход
        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        // Поиск контактов
        private void button1_Click(object sender, EventArgs e)
        {
            var searchText = textBox1.Text.Trim();
            if (!string.IsNullOrEmpty(searchText))
            {
                var results = phoneBook.SearchByName(searchText);
                DisplayContacts(results);
            }
            else
            {
                DisplayContacts(phoneBook.GetAllContacts());
            }
        }
    }
}