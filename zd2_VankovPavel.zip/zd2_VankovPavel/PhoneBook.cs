﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace zd2_VankovPavel
{
    public class PhoneBook
    {
        private List<Contact> contacts = new List<Contact>(); // Список контактов

        // Добавить контакт (объект)
        public void AddContact(Contact contact)
        {
            if (contact == null)
                throw new ArgumentNullException(nameof(contact));

            contacts.Add(contact);
        }

        // Добавить контакт (данные)
        public void AddContact(string name, string phone)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Имя не может быть пустым");

            if (string.IsNullOrWhiteSpace(phone))
                throw new ArgumentException("Телефон не может быть пустым");

            contacts.Add(new Contact { Name = name, Phone = phone });
        }

        // Удалить контакт (объект)
        public bool RemoveContact(Contact contact)
        {
            return contacts.Remove(contact);
        }

        // Удалить контакт (по имени)
        public bool RemoveContact(string name)
        {
            var contact = contacts.FirstOrDefault(c => c.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
            return contact != null && contacts.Remove(contact);
        }

        // Поиск по имени
        public List<Contact> SearchByName(string name)
        {
            return contacts
                .Where(c => c.Name.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
                .OrderBy(c => c.Name)
                .ToList();
        }

        // Все контакты
        public List<Contact> GetAllContacts()
        {
            return contacts.OrderBy(c => c.Name).ToList();
        }
    }
}