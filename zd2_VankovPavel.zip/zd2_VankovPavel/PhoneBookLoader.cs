﻿using System;
using System.IO;
using System.Linq;

namespace zd2_VankovPavel
{
    public static class PhoneBookLoader
    {
        // Загрузка из файла
        public static void Load(PhoneBook phoneBook, string fileName)
        {
            if (phoneBook == null)
                throw new ArgumentNullException(nameof(phoneBook));

            if (!File.Exists(fileName))
                throw new FileNotFoundException("Файл не найден", fileName);

            var lines = File.ReadAllLines(fileName);
            foreach (var line in lines)
            {
                var parts = line.Split(';');
                if (parts.Length == 2)
                {
                    phoneBook.AddContact(new Contact
                    {
                        Name = parts[0].Trim(),
                        Phone = parts[1].Trim()
                    });
                }
            }
        }

        // Сохранение в файл
        public static void Save(PhoneBook phoneBook, string fileName)
        {
            if (phoneBook == null)
                throw new ArgumentNullException(nameof(phoneBook));

            var lines = phoneBook.GetAllContacts()
                                .Select(c => $"{c.Name};{c.Phone}");
            File.WriteAllLines(fileName, lines);
        }
    }
}