﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zd2_VankovPavell
{
    public partial class AddProductForm : Form
    {
        public string ProductName => txtName.Text;
        public decimal ProductPrice => numPrice.Value;
        public int ProductCount => (int)numCount.Value;

        public AddProductForm()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ProductName))
            {
                MessageBox.Show("Введите наименование.");
                return;
            }

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}