﻿namespace zd2_VankovPavell
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.магазинToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAddProduct = new System.Windows.Forms.ToolStripMenuItem();
            this.menuBuyProduct = new System.Windows.Forms.ToolStripMenuItem();
            this.menuListProducts = new System.Windows.Forms.ToolStripMenuItem();
            this.menuProfit = new System.Windows.Forms.ToolStripMenuItem();
            this.eventLog1 = new System.Diagnostics.EventLog();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.магазинToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(301, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // магазинToolStripMenuItem
            // 
            this.магазинToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuAddProduct,
            this.menuBuyProduct,
            this.menuListProducts,
            this.menuProfit});
            this.магазинToolStripMenuItem.Name = "магазинToolStripMenuItem";
            this.магазинToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.магазинToolStripMenuItem.Text = "Магазин";
            // 
            // menuAddProduct
            // 
            this.menuAddProduct.Name = "menuAddProduct";
            this.menuAddProduct.Size = new System.Drawing.Size(162, 22);
            this.menuAddProduct.Text = "Добавить товар";
            this.menuAddProduct.Click += new System.EventHandler(this.menuAddProduct_Click);
            // 
            // menuBuyProduct
            // 
            this.menuBuyProduct.Name = "menuBuyProduct";
            this.menuBuyProduct.Size = new System.Drawing.Size(162, 22);
            this.menuBuyProduct.Text = "Купить товар";
            this.menuBuyProduct.Click += new System.EventHandler(this.menuBuyProduct_Click);
            // 
            // menuListProducts
            // 
            this.menuListProducts.Name = "menuListProducts";
            this.menuListProducts.Size = new System.Drawing.Size(162, 22);
            this.menuListProducts.Text = "Список товаров";
            this.menuListProducts.Click += new System.EventHandler(this.menuListProducts_Click);
            // 
            // menuProfit
            // 
            this.menuProfit.Name = "menuProfit";
            this.menuProfit.Size = new System.Drawing.Size(162, 22);
            this.menuProfit.Text = "Прибыль";
            this.menuProfit.Click += new System.EventHandler(this.menuProfit_Click);
            // 
            // eventLog1
            // 
            this.eventLog1.SynchronizingObject = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(301, 128);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Магазин";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem магазинToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuAddProduct;
        private System.Windows.Forms.ToolStripMenuItem menuBuyProduct;
        private System.Windows.Forms.ToolStripMenuItem menuListProducts;
        private System.Windows.Forms.ToolStripMenuItem menuProfit;
        private System.Diagnostics.EventLog eventLog1;
    }
}