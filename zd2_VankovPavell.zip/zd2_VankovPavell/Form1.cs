﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zd2_VankovPavell
{
    public partial class Form1 : Form
    {
        private Shop shop = new Shop();

        public Form1()
        {
            InitializeComponent();
        }

        private void menuAddProduct_Click(object sender, EventArgs e)
        {
            var form = new AddProductForm();
            if (form.ShowDialog() == DialogResult.OK)
            {
                shop.CreateProduct(form.ProductName, form.ProductPrice, form.ProductCount);
                MessageBox.Show("Товар добавлен.");
            }
        }

        private void menuBuyProduct_Click(object sender, EventArgs e)
        {
            var form = new BuyProductForm();
            if (form.ShowDialog() == DialogResult.OK)
            {
                shop.Sell(form.ProductName);
            }
        }

        private void menuListProducts_Click(object sender, EventArgs e)
        {
            var list = shop.GetProductInfoList();
            MessageBox.Show(string.Join(Environment.NewLine, list), "Список товаров");
        }

        private void menuProfit_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Текущая прибыль: {shop.GetProfit()} руб.", "Прибыль");
        }
    }
}