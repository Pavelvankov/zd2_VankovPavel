﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd2_VankovPavell
{
    public class Shop
    {
        private Dictionary<Product, int> products;
        private decimal profit;

        public Shop()
        {
            products = new Dictionary<Product, int>();
            profit = 0;
        }

        public void CreateProduct(string name, decimal price, int count)
        {
            var product = new Product(name, price);
            products[product] = count;
        }

        public void Sell(Product product)
        {
            if (products.ContainsKey(product))
            {
                if (products[product] > 0)
                {
                    products[product]--;
                    profit += product.Price;
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Нет в наличии!");
                }
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Товар не найден!");
            }
        }

        public void Sell(string productName)
        {
            var product = FindByName(productName);
            if (product != null)
            {
                Sell(product);
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Товар не найден!");
            }
        }

        public Product FindByName(string name)
        {
            foreach (var product in products.Keys)
            {
                if (product.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                    return product;
            }
            return null;
        }

        public List<string> GetProductInfoList()
        {
            var list = new List<string>();
            foreach (var item in products)
            {
                list.Add($"{item.Key.GetInfo()}; Количество: {item.Value}");
            }
            return list;
        }

        public decimal GetProfit()
        {
            return profit;
        }
    }
}